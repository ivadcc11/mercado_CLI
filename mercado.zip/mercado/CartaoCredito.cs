using System.Globalization;
using System;

namespace MercadoPagamentos
{
    // Classe: CartaoCredito (Herda de Pagamento)
    class CartaoCredito : Pagamento
    {
        public string NumeroCartao { get; }
        public int Parcelas { get; }

        public CartaoCredito(double valor, string numeroCartao, int parcelas) : base(valor)
        {
            NumeroCartao = numeroCartao;
            Parcelas = parcelas;
        }

        public override void Processar()
        {
            var culture = CultureInfo.GetCultureInfo("pt-BR");
            Console.WriteLine("Processando pagamento com Cart�o de Cr�dito...");
            Console.WriteLine($"Cart�o: **** **** **** {NumeroCartao[^4..]}");
            Console.WriteLine($"Valor: {Valor.ToString("C", culture)} | Parcelas: {Parcelas}x");
            Console.WriteLine("Autoriza��o: APROVADA (simula��o)");
        }
    }
}
