using System;
using System.Globalization;

namespace MercadoPagamentos
{
    // Classe: Boleto (Herda de Pagamento)
    class Boleto : Pagamento
    {
        public string CodigoBarras { get; }
        public DateTime DataVencimento { get; }

        public Boleto(double valor, string codigoBarras, DateTime dataVencimento) : base(valor)
        {
            CodigoBarras = codigoBarras;
            DataVencimento = dataVencimento;
        }

        public override void Processar()
        {
            var culture = CultureInfo.GetCultureInfo("pt-BR");
            // Mostrar c�digo de barras antes da mensagem de processamento
            Console.WriteLine($"C�digo de barras gerado: {CodigoBarras}");
            Console.WriteLine("Processando pagamento via Boleto...");
            Console.WriteLine($"Vencimento: {DataVencimento:dd/MM/yyyy}");
            Console.WriteLine($"Valor: {Valor.ToString("C", culture)}");
            Console.WriteLine("Boleto emitido com sucesso (simula��o)");
        }
    }
}
