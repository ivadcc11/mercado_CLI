using System;
using System.Globalization;

namespace MercadoPagamentos
{
    // Classe: Pix (Herda de Pagamento)
    class Pix : Pagamento
    {
        public string ChavePix { get; }
        public string CodigoCopiaECola { get; }

        public Pix(double valor, string chavePix, string codigoCopiaECola) : base(valor)
        {
            ChavePix = chavePix;
            CodigoCopiaECola = codigoCopiaECola;
        }

        public override void Processar()
        {
            var culture = CultureInfo.GetCultureInfo("pt-BR");
            Console.WriteLine("Processando pagamento via Pix...");
            Console.WriteLine($"Chave: {ChavePix}");
            Console.WriteLine($"C�digo (copia e cola) gerado: {CodigoCopiaECola}");
            Console.WriteLine($"Valor a receber: {Valor.ToString("C", culture)}");
            Console.WriteLine("Status: Aguardando confirma��o instant�nea (simula��o)");
        }
    }
}
