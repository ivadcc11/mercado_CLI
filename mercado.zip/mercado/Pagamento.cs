using System;

namespace MercadoPagamentos
{
    // Classe Base: Pagamento (abstrata)
    abstract class Pagamento
    {
        public double Valor { get; set; }
        public DateTime Data { get; set; }

        protected Pagamento(double valor)
        {
            Valor = valor;
            Data = DateTime.Now;
        }

        // m�todo abstrato que obriga implementa��o nas subclasses
        public abstract void Processar();
    }
}
