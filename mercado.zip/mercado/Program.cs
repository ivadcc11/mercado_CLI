﻿// Programa principal para o desafio de herança e polimorfismo.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MercadoPagamentos
{
    class Program
    {
        static void Main()
        {
            CultureInfo culture = CultureInfo.GetCultureInfo("pt-BR");

            var products = new List<Product>
            {
                new Product(1, "Arroz 5kg", 28.90m),
                new Product(2, "Feijão 1kg", 7.50m),
                new Product(3, "Óleo 900ml", 8.99m),
                new Product(4, "Macarrão 500g", 4.20m),
                new Product(5, "Açúcar 2kg", 6.40m)
            };

            var cart = new ShoppingCart();

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("=== MERCADO CLI ===");
                Console.WriteLine("1. Listar produtos");
                Console.WriteLine("2. Adicionar ao carrinho");
                Console.WriteLine("3. Remover do carrinho");
                Console.WriteLine("4. Visualizar carrinho");
                Console.WriteLine("5. Finalizar compra");
                Console.WriteLine("0. Sair");
                Console.Write("Escolha uma opção: ");
                var opt = Console.ReadLine()?.Trim();

                Console.WriteLine();
                switch (opt)
                {
                    case "1":
                        ShowProducts(products);
                        break;
                    case "2":
                        ShowProducts(products);
                        Console.Write("Id do produto: ");
                        if (!int.TryParse(Console.ReadLine(), out var addId))
                        {
                            Console.WriteLine("Id inválido.");
                            break;
                        }
                        Console.Write("Quantidade: ");
                        if (!int.TryParse(Console.ReadLine(), out var qty) || qty <= 0)
                        {
                            Console.WriteLine("Quantidade inválida.");
                            break;
                        }
                        var pAdd = products.FirstOrDefault(p => p.Id == addId);
                        if (pAdd == null) { Console.WriteLine("Produto não encontrado."); break; }
                        cart.Add(pAdd, qty);
                        Console.WriteLine($"Adicionado {qty} x {pAdd.Name}.");
                        break;
                    case "3":
                        if (cart.IsEmpty()) { Console.WriteLine("Carrinho vazio."); break; }
                        cart.Print(culture);
                        Console.Write("Id do produto para remover: ");
                        if (!int.TryParse(Console.ReadLine(), out var remId))
                        {
                            Console.WriteLine("Id inválido.");
                            break;
                        }
                        cart.Remove(remId);
                        break;
                    case "4":
                        if (cart.IsEmpty()) Console.WriteLine("Carrinho vazio.");
                        else cart.Print(culture);
                        break;
                    case "5":
                        if (cart.IsEmpty()) { Console.WriteLine("Carrinho vazio."); break; }

                        // Mostrar resumo
                        var receiptText = GenerateReceipt(cart, culture);
                        Console.WriteLine("--- RESUMO DE COMPRA ---");
                        Console.WriteLine(receiptText);

                        // Escolher forma de pagamento
                        Console.WriteLine("Escolha a forma de pagamento:");
                        Console.WriteLine("1 - Cartão");
                        Console.WriteLine("2 - Pix");
                        Console.WriteLine("3 - Boleto");
                        Console.Write("Opção: ");
                        var payOpt = Console.ReadLine()?.Trim();

                        Pagamento pagamento = null;
                        switch (payOpt)
                        {
                            case "1":
                                Console.Write("Número do cartão (somente dígitos, pode ter espaços ou traços): ");
                                var rawNumero = Console.ReadLine()?.Trim() ?? string.Empty;
                                // remover espaços e traços
                                var numeroClean = new string(rawNumero.Where(c => !char.IsWhiteSpace(c) && c != '-').ToArray());
                                if (numeroClean.Length == 0 || !numeroClean.All(char.IsDigit))
                                {
                                    Console.WriteLine("Número inválido. Deve conter apenas números.");
                                    break;
                                }

                                Console.Write("Parcelas: ");
                                if (!int.TryParse(Console.ReadLine(), out var parcelas) || parcelas <= 0)
                                {
                                    Console.WriteLine("Parcelas inválidas. Cancelando pagamento.");
                                    break;
                                }

                                pagamento = new CartaoCredito((double)cart.Total(), numeroClean, parcelas);
                                break;
                            case "2":
                                Console.Write("Chave Pix: ");
                                var chave = Console.ReadLine()?.Trim() ?? string.Empty;
                                if (string.IsNullOrWhiteSpace(chave))
                                {
                                    Console.WriteLine("Chave Pix inválida.");
                                    break;
                                }
                                // Gerar CodigoCopiaECola automaticamente
                                var codigoPix = Guid.NewGuid().ToString("N");
                                pagamento = new Pix((double)cart.Total(), chave, codigoPix);
                                break;
                            case "3":
                                Console.Write("Data de vencimento (dd/MM/yyyy): ");
                                var dtStr = Console.ReadLine()?.Trim() ?? string.Empty;
                                if (!DateTime.TryParseExact(dtStr, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var venc))
                                {
                                    Console.WriteLine("Data inválida. Use dd/MM/yyyy. Cancelando pagamento.");
                                    break;
                                }
                                // Gerar código de barras automaticamente (ex: 47 dígitos)
                                var rnd = new Random();
                                var codigoBarras = string.Concat(Enumerable.Range(0, 47).Select(_ => rnd.Next(0, 10).ToString()));
                                pagamento = new Boleto((double)cart.Total(), codigoBarras, venc);
                                break;
                            default:
                                Console.WriteLine("Opção de pagamento inválida.");
                                break;
                        }

                        if (pagamento != null)
                        {
                            pagamento.Processar();
                            Console.WriteLine("Compra finalizada com sucesso.");
                            cart = new ShoppingCart(); // novo carrinho
                        }

                        break;
                    case "0":
                        Console.WriteLine("Saindo...");
                        return;
                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }
            }
        }

        static void ShowProducts(List<Product> products)
        {
            Console.WriteLine("Produtos disponíveis:");
            foreach (var p in products)
            {
                Console.WriteLine($"{p.Id}. {p.Name} - {p.Price.ToString("C", CultureInfo.GetCultureInfo("pt-BR"))}");
            }
        }

        // Gera o texto do recibo e NÃO salva em arquivo
        static string GenerateReceipt(ShoppingCart cart, CultureInfo culture)
        {
            var sw = new System.Text.StringBuilder();
            sw.AppendLine("RECIBO - MERCADO");
            sw.AppendLine($"Data: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
            sw.AppendLine(new string('-', 30));
            foreach (var item in cart.Items)
            {
                sw.AppendLine($"{item.Product.Name} x{item.Quantity} - {item.Subtotal.ToString("C", culture)}");
            }
            sw.AppendLine(new string('-', 30));
            sw.AppendLine($"TOTAL: {cart.Total().ToString("C", culture)}");

            return sw.ToString();
        }
    }

    record Product(int Id, string Name, decimal Price);

    class CartItem
    {
        public Product Product { get; }
        public int Quantity { get; private set; }
        public decimal Subtotal => Product.Price * Quantity;
        public CartItem(Product product, int quantity)
        {
            Product = product;
            Quantity = quantity;
        }
        public void Add(int qty) => Quantity += qty;
    }

    class ShoppingCart
    {
        private readonly List<CartItem> _items = new();
        public IReadOnlyList<CartItem> Items => _items.AsReadOnly();

        public void Add(Product product, int quantity)
        {
            var existing = _items.FirstOrDefault(i => i.Product.Id == product.Id);
            if (existing != null) existing.Add(quantity);
            else _items.Add(new CartItem(product, quantity));
        }

        public void Remove(int productId)
        {
            var existing = _items.FirstOrDefault(i => i.Product.Id == productId);
            if (existing == null) { Console.WriteLine("Produto não encontrado no carrinho."); return; }
            _items.Remove(existing);
            Console.WriteLine($"Removido {existing.Product.Name} do carrinho.");
        }

        public bool IsEmpty() => !_items.Any();

        public decimal Total() => _items.Sum(i => i.Subtotal);

        public void Print(CultureInfo culture)
        {
            Console.WriteLine("Itens no carrinho:");
            foreach (var item in _items)
            {
                Console.WriteLine($"{item.Product.Id}. {item.Product.Name} x{item.Quantity} - {item.Subtotal.ToString("C", culture)}");
            }
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"TOTAL: {Total().ToString("C", culture)}");
        }
    }
}
